<meta charset="utf-8" />
<?php
include('simple_html_dom.php');


if (isset($_POST["submit"])) {
    $site = $_POST['site_noticia'];
    $date = date("Y-m-d H:i:s");

    function getTitle($site_url){
        $ch = curl_init();
        curl_setopt ($ch, CURLOPT_URL, $site_url);
        curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 5);
        ob_start();
        curl_exec($ch); 
        curl_close($ch);
        $file_contents = ob_get_contents();
        ob_end_clean();
       
        if (preg_match('/<title>([^<]++)/', $file_contents, $matches) == FALSE)
        $erro = "Erro ao resgatar o titulo do site"; // se der algum erro
       
        return $matches[1];
    }

    function getNew($site_url){
        $html = file_get_html($site_url);
        $result = "";
        foreach($html->find('p.content-text__container') as $new){
            $result .= $new. '<br>'; 
        }
        return $result;
    }

    function saveImg($site_url){
        $html = file_get_html($site_url);
        foreach($html->find('meta[itemprop=image]') as $img) 

        $file = $img->content;
        $newfile = substr(getTitle($site_url), 0, 6).'.jpg';
        $newfile = strtolower($newfile);

       if (!copy($file, $newfile)) 
        echo "falha ao copiar $file...\n";
   }

$titulo = getTitle($site);
$noticia = getNew($site);   
$slug = str_replace(' ', '-', $titulo); 
$slug= strtolower($slug);
$titulo_img = substr($titulo, 0, 6).'.png';
$titulo_img = strtolower($titulo_img);
//INSERT BD

$servername = "localhost";
$username = "root";
$password = "deu147";
$dbname = "juliano";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("INSERT INTO site_noticias (noticia_id, noticia_dataCadastro, noticia_dataAlteracao, noticia_titulo, noticia_texto, noticia_video, noticia_cadPor, noticia_tags, noticia_fonte, noticia_categoria, noticia_slug) VALUES (:noticia_id, :noticia_dataCadastro, :noticia_dataAlteracao, :noticia_titulo, :noticia_texto, :noticia_video, :noticia_cadPor, :noticia_tags, :noticia_fonte, :noticia_categoria, :noticia_slug)");

    $stmt->bindParam(':noticia_id', $noticia_id);
    $stmt->bindParam(':noticia_dataCadastro', $noticia_dataCadastro);
    $stmt->bindParam(':noticia_dataAlteracao', $noticia_dataAlteracao);
    $stmt->bindParam(':noticia_titulo', $noticia_titulo); 
    $stmt->bindParam(':noticia_texto',  $noticia_texto);
    $stmt->bindParam(':noticia_video', $noticia_video);
    $stmt->bindParam(':noticia_cadPor', $noticia_cadPor);
    $stmt->bindParam(':noticia_tags', $noticia_tags);
    $stmt->bindParam(':noticia_fonte', $noticia_fonte);
    $stmt->bindParam(':noticia_categoria', $noticia_categoria); 
    $stmt->bindParam(':noticia_slug', $noticia_slug);

    // insert one row
    $noticia_id = 'id';
    $noticia_dataCadastro = $date;
    $noticia_dataAlteracao = $date;
    $noticia_titulo = $titulo; 
    $noticia_texto = $noticia;
    $noticia_video = '';
    $noticia_cadPor = '23';
    $noticia_tags = 'zapshop';
    $noticia_fonte = 'TechTudo';
    $noticia_categoria = '3';
    $noticia_slug = $slug;
    $stmt->execute();

    $stmt = $conn->query("SELECT * FROM site_noticias ORDER BY noticia_id DESC");
    $result = $stmt->fetch(PDO::FETCH_OBJ);
    $id_noticia = $result->noticia_id;

    $stmt = $conn->prepare("INSERT INTO site_noticias_imagens (notImg_id, notImg_img, notImg_noticia) VALUES (:notImg_id, :notImg_img, :notImg_noticia)");

    $stmt->bindParam(':notImg_id', $notImg_id);
    $stmt->bindParam(':notImg_img', $notImg_img);
    $stmt->bindParam(':notImg_noticia', $notImg_noticia);

    // insert one row
    $notImg__id = 'id';
    $notImg_img = $titulo_img;
    $notImg_noticia = $id_noticia;
    $stmt->execute();

    echo 'A noticia foi postada com sucesso, confira: http://zapshop.com.br/blog/'.$slug.'';
    echo '<br /><br />Algum erro? apague clicando <a href="apagar.php?id='.$id_noticia.'">aqui</a>';
}catch(PDOException $e){
    echo $e->getMessage();
    }

$conn = null;
saveImg($site);
}
?>

<form action="" method="POST">
Digite o site da noticia:
<input type="text" name="site_noticia"><BR>
<input type="submit" value="Submit" name="submit">
</form>