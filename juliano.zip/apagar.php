<?php
$id = $_GET['id'];
if(empty($id)){
	echo '<script type="text/javascript"> window.location.href="http://google.com"; </script>';
}
if(isset($id)){

	$servername = "localhost";
	$username = "root";
	$password = "deu147";
	$dbname = "juliano";

	try {
	    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	    // set the PDO error mode to exception
	    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	    $sql=$conn->prepare("DELETE FROM site_noticias WHERE noticia_id='$id'");
		$sql->execute();

		$sql=$conn->prepare("DELETE FROM site_noticias_imagens WHERE notImg_noticia='$id'");
		$sql->execute();
 		
 		echo '<script type="text/javascript"> window.location.href="index.php"; </script>';
	}catch(PDOException $e){
	    echo $e->getMessage();
	}
}
    ?>